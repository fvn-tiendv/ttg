<?php

	$setting=unserialize(@file_get_contents(DATA_DIR.'/setting/overnotes.dat'));
	ini_set('mbstring.http_input', 'pass');
	parse_str($_SERVER['QUERY_STRING'],$_GET);
	$keyword=isset($_GET['k'])?trim($_GET['k']):'';
	$category=isset($_GET['c'])?trim($_GET['c']):'';
	$page=isset($_GET['p'])?trim($_GET['p']):'';
	$base_title = !empty($setting['title'])? $setting['title'] : 'OverNotes';

?><!Doctype html>
<html lang="ja">
<head>
<?php
	$contribute=get_contribute($contribute_id);
		$title=$contribute['title'];
	$category_id=$contribute['category'];
	$category_data=unserialize(@file_get_contents(DATA_DIR.'/category/'.$category_id.'.dat'));
	$category_name=$category_data['name'];
	$category_text=@$category_data['text'];
	$category_url=$category_data['id'];
	$field_id=$contribute['field'];
	$id=$contribute['id'];
	$field=get_field($field_id);
	$date=$contribute['public_begin_datetime'];
	$url=$contribute['url'].'/';

	foreach($field as $field_index=>$field_data){
		${$field_data['code'].'_Name'}=$field_data['name'];
		${$field_data['code'].'_Value'}=make_value(
		$field_data['name']
				,@$contribute['data'][$field_id][$field_index]
			,$field_data['type']
			,$id
			,$field_id
			,$field_index
		);
		if($field_data['type']=='image'){
			${$field_data['code'].'_Src'}=ROOT_URI.'/_data/contribute/images/'.@$contribute['data'][$field_id][$field_index];
		}
	}

?>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $title; ?>｜<?php echo $base_title; ?></title>
<?php
	if($description_Value){
?>
  <meta name="description" content="<?php echo $description_Value; ?>" />
  <?php
	}else{
?>
  <meta name="description" content="" />
<?php
	}
?>
<?php
	if($keywords_Value){
?>
  <meta name="keywords" content="<?php echo $keywords_Value; ?>" />
  <?php
	}else{
?>
  <meta name="keywords" content="" />
<?php
	}
?>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="format-detection" content="telephone=no">
<meta http-equiv="Content-Style-Type" content="text/css" />
<meta http-equiv="Content-Script-Type" content="text/javascript" />
<link  href="../../css/styles.css" rel="stylesheet" type="text/css" />
<link  href="../../css/style_sp.css" rel="stylesheet" type="text/css" />
<link  href="../../css/responsive.css" rel="stylesheet" type="text/css" />
<link  href="../../css/under.css" rel="stylesheet" type="text/css" />
<link  href="../../css/under_responsive.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="../../css/lightbox.min.css">
<script src="../../js/jquery.js" type="text/javascript"></script>
<script src="../../js/jquery.scroll.js" type="text/javascript"></script>
<script src="../../js/rollover.min.js" type="text/javascript"></script>
<script src="../../js/common.js" type="text/javascript"></script>


<!-- Begin Google Analytics -->
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-90531692-36', 'auto');
  ga('send', 'pageview');

</script>
<!-- End Google Analytics -->
</head>
<body id="case_dt" class="under">
<div id="wrapper">
 <div id="header" class="clearfix">
    <div class="inner">
      <h1 id="top"><?php echo $title; ?>｜<?php echo $base_title; ?></h1>
      <div id="header_top">
        <p id="logo"><a href="http://www.sobudai-d.com"><img src="../../images/logo.png" alt="相武台駅前歯科クリニック"/></a></p>
        <p id="nav-icon4" class="box_sp"><span></span> <span></span> <span></span></p>
        <!--gnavi pc-->
        <ul id="gnavi">
          <li><a href="../../clinic/index.html">コンセプト</a></li>
          <li><a href="../../clinic/staff.html">スタッフ紹介</a></li>
          <li><a href="../../clinic/clinic.html">医院紹介・アクセス</a></li>
          <li><a href="../../clinic/flow.html">診療の流れ</a></li>
        </ul>
        <!--gnavi pc end--> 
        <!--gnavi sp-->
        <div id="gnavi_sp" class="clearfix">
          <ul>
            <li><a href="http://www.sobudai-d.com">トップページ</a></li>
            <li><a href="../../clinic/index.html">コンセプト</a></li>
            <li><a href="../../clinic/staff.html">スタッフ紹介</a></li>
            <li><a href="../../clinic/clinic.html">医院紹介・アクセス</a></li>
            <li><a href="../../clinic/flow.html">診療の流れ</a></li>
            <li><a href="../../clinic/sitemap.html">サイトマップ</a></li>
            <li><a href="../../blog/index.php">ブログ</a></li>
            <li><a href="../../treatment/cost.html">自費と保険の違い</a></li>
            <li><a href="../../clinic/kids.html">お母さんとお子さんが通いやすい歯科医院です</a></li>
            <li class="sub"><a href="#">治療メニュー</a>
              <ul class="sub_menu">
                <li><a href="../../treatment/index.html">虫歯治療</a></li>
                <li><a href="../../treatment/perio.html">歯周病治療</a></li>
                <li><a href="../../treatment/child.html">小児歯科</a></li>
                <li><a href="../../treatment/faq.html">小児歯科のQ&amp;A</a></li>
                <li><a href="../../treatment/prevent.html">予防歯科</a></li>
                <li><a href="../../treatment/implant.html">インプラント治療</a></li>
                <li><a href="../../treatment/denture.html">入れ歯治療</a></li>
                <li><a href="../../treatment/esthe.html">審美歯科･ホワイトニング</a></li>
                <li><a href="../../treatment/ortho.html">矯正歯科</a></li>
                <li><a href="../../treatment/surgery.html">口腔外科</a></li>
              </ul>
            </li>
          </ul>
        </div>
        <!--end gnavi sp--> 
      </div>
    </div>
  </div>
  
  
  
  <!-- main start -->
  <div id="main" class="clearfix"> 
    <!-- top_info start -->
    <div id="top_info" class="clearfix">
      <div class="inner clearfix">
        <h2><?php echo mb_strimwidth($title, 0, 45, '…', 'UTF-8'); ?><br>
        	<span>Blog</span>
        </h2> 
      </div>
    </div>
    <div id="topic_path" class="clearfix">
      <div class="inner clearfix">
        <ul>
          <li><a href="http://www.sobudai-d.com">ホーム</a>&nbsp;&gt;&nbsp;</li>
          <li><a href="../"><?php echo $base_title; ?></a>&nbsp;&gt;&nbsp;</li>
          <li><a href="../<?php echo $category_url; ?>/"><?php echo $category_name; ?></a>&nbsp;&gt;&nbsp;</li>
          <li><?php echo mb_strimwidth($title, 0, 45, '…', 'UTF-8'); ?></li>
        </ul>
      </div>
    </div>
    <!-- top_info end --> 
    <!-- content start -->
    <div class="under_inner01 clearfix">
      <div id="content">
        <div class="inner">
          <h3><?php echo $title; ?></h3>
          <!--section01-->
          <div class="section clearfix">
            <?php
	if($img_01_Value){
?>
              <p class="img_blog_lg"><a class="example-image-link" href="<?php echo $img_01_Src; ?>" data-lightbox="example-1"><img src="<?php echo $img_01_Src; ?>" alt="<?php echo $title; ?>" class="example-image" /></a></p>
            <?php
	}
?>
          </div>
          </div>
          </div>
          </div>
          <div class="under_inner02 clearfix">
          <div class="inner">
          <!--section02 end-->
          <?php if($content02_Value!=""||$img_02_Value!=""||$img_03_Value!=""||$img_04_Value!=""){  ?>
          <?php
	if($content02_Value){
?>
            <h4><?php echo $content02_Value; ?></h4>
          <?php
	}
?>
          <div class="section clearfix">
            <ul class="img_blog01">
              <?php
	if($img_02_Value){
?>
                <li>
                	<p><a class="example-image-link" href="<?php echo $img_02_Src; ?>" data-lightbox="example-1"><img src="<?php echo $img_02_Src; ?>" alt="<?php echo $title; ?>" class="example-image" /></a>
                    </p></li>
              <?php
	}
?>
              <?php
	if($img_03_Value){
?>
                <li><p><a class="example-image-link" href="<?php echo $img_03_Src; ?>" data-lightbox="example-1"><img src="<?php echo $img_03_Src; ?>" alt="<?php echo $title; ?>" class="example-image" /></a></p></li>
              <?php
	}
?>
              <?php
	if($img_04_Value){
?>
                <li><p><a class="example-image-link" href="<?php echo $img_04_Src; ?>" data-lightbox="example-1"><img src="<?php echo $img_04_Src; ?>" alt="<?php echo $title; ?>" class="example-image" /></a></p></li>
              <?php
	}
?>
            </ul>
          </div>
          <?php }?>
          
          <!--section03 end-->
          <?php if($content03_Value!=""||$content04_Value!=""||$img_05_Value!=""||$img_06_Value!=""||$img_07_Value!=""){  ?>
          <?php
	if($content03_Value){
?>
            <h4><?php echo $content03_Value; ?></h4>
          <?php
	}
?>
          <div class="section clearfix">
            <?php
	if($content04_Value){
?>
              <p><?php echo $content04_Value; ?></p>
            <?php
	}
?>
            <ul class="img_blog01">
              <?php
	if($img_05_Value){
?>
                <li><p><a class="example-image-link" href="<?php echo $img_05_Src; ?>" data-lightbox="example-1"><img src="<?php echo $img_05_Src; ?>" alt="<?php echo $title; ?>" class="example-image" /></a></p></li>
              <?php
	}
?>
              <?php
	if($img_06_Value){
?>
                <li><p><a class="example-image-link" href="<?php echo $img_06_Src; ?>" data-lightbox="example-1"><img src="<?php echo $img_06_Src; ?>" alt="<?php echo $title; ?>" class="example-image" /></a></p></li>
              <?php
	}
?>
              <?php
	if($img_07_Value){
?>
                <li><p><a class="example-image-link" href="<?php echo $img_07_Src; ?>" data-lightbox="example-1"><img src="<?php echo $img_07_Src; ?>" alt="<?php echo $title; ?>" class="example-image" /></a></p></li>
              <?php
	}
?>
            </ul>
          </div>
          <?php }?>
          
          <!--section03 end-->
          <?php if($content05_Value!=""||$content06_Value!=""||$img_08_Value!=""||$img_09_Value!=""||$img_10_Value!=""){  ?>
          <?php
	if($content05_Value){
?>
            <h4><?php echo $content05_Value; ?></h4>
          <?php
	}
?>
          <div class="section clearfix">
            <?php
	if($content06_Value){
?>
              <p><?php echo $content06_Value; ?></p>
            <?php
	}
?>
            <ul class="img_blog01">
              <?php
	if($img_08_Value){
?>
                <li><p><a class="example-image-link" href="<?php echo $img_08_Src; ?>" data-lightbox="example-1"><img src="<?php echo $img_08_Src; ?>" alt="<?php echo $title; ?>" class="example-image" /></a></p></li>
              <?php
	}
?>
              <?php
	if($img_09_Value){
?>
                <li><p><a class="example-image-link" href="<?php echo $img_09_Src; ?>" data-lightbox="example-1"><img src="<?php echo $img_09_Src; ?>" alt="<?php echo $title; ?>" class="example-image" /></a></p></li>
              <?php
	}
?>
              <?php
	if($img_10_Value){
?>
                <li><p><a class="example-image-link" href="<?php echo $img_10_Src; ?>" data-lightbox="example-1"><img src="<?php echo $img_10_Src; ?>" alt="<?php echo $title; ?>" class="example-image" /></a></p></li>
              <?php
	}
?>
            </ul>
          </div>
          <?php }?>
          
         
          
          <div class="section clearfix">
            <p class="center btn_right mb0"><a href="../<?php echo $category_url; ?>/" class="btn-default">一覧へ&gt;</a></p>
          </div>
          </div>
        </div>
  </div>
  <!-- content end --> 
<!-- main end -->

<div id="footer">
    <div id="footer_top">
      <div class="inner">
        <p id="footer_logo"><a href="http://www.sobudai-d.com"><img src="../../images/logo_ft.png" alt="相武台駅前歯科クリニック"/></a></p>
        <p class="footer_address">〒252-0011<br class="box_sp">
          神奈川県座間市相武台1-32-1<br class="box_sp">
          アンプルールベトン相武台1F</p>
        <ul>
          <li>駅徒歩1分</li>
          <li>駐車場有</li>
          <li>土日診療</li>
          <li>年中無休</li>
          <li>キッズスペース有</li>
        </ul>
        <p class="footer_tel">tel.00-00-0000</p>
        <p class="footer_time">診療時間<br class="box_sp">
          10:00～13:00　/　15:00～20:00<br class="box_sp">
          （ 土日 18:00まで ）</p>
      </div>
    </div>
    <div class="footer_map">
      <div class="gMap gMapZoom15 gMapDisableScrollwheel gMapNavigationSmall gMapMinifyInfoWindow" style="width:100%; height:450px;">
        <div class="gMapCenter">
          <p class="gMapLatLng">35.4997902,139.40836250000007</p>
        </div>
        <div class="gMapMarker">
          <div class="gMapInfoWindow"><span style="font-weight: bold">相武台駅前歯科クリニック</span><br>
          	〒252-0011 神奈川県座間市相武台1-32-1　アンプルールベトン相武台1F
          </div>
          <p class="gMapLatLng">35.4997902,139.40836250000007</p>
        </div>
      </div>
    </div>
    <div class="inner">
      <p class="link_sika"><a href="https://www.shika-town.com/" onclick="ga('send', 'event', 'content', 'shikatown');"><img src="../../images/sikatown.png" alt="歯科タウン"/></a></p>
    </div>
    <div id="footer_bt">
      <div class="inner">
        <ul>
          <li><a href="../../treatment/index.html">虫歯治療</a></li>
          <li><a href="../../treatment/child.html">小児歯科</a></li>
          <li><a href="../../treatment/perio.html">歯周病治療</a></li>
          <br class="box_sp">
          <li><a href="../../treatment/prevent.html">予防歯科</a></li>
          <li><a href="../../treatment/implant.html">インプラント治療</a></li>
          <br class="box_pc">
          <li><a href="../../treatment/denture.html">入れ歯治療</a></li>
          <br class="box_sp">
          <li><a href="../../treatment/esthe.html">審美歯科・ホワイトニング</a></li>
          <li><a href="../../treatment/ortho.html">矯正歯科</a></li>
          <br class="box_sp">
          <li><a href="../../treatment/surgery.html">口腔外科</a></li>
          <li><a href="../../treatment/cost.html">自費と保険の違い</a></li>
          <br>
          <li><a href="../../clinic/kids.html">お母さんとお子さんが通いやすい歯科医院です</a></li>
          <br class="box_sp">
          <li><a href="../../treatment/faq.html">小児歯科のQ&amp;A</a></li>
          <br class="box_pc">
          <li><a href="http://www.sobudai-d.com">トップページ</a></li>
          <li><a href="../../clinic/index.html">コンセプト</a></li>
          <br class="box_sp">
          <li><a href="../../clinic/staff.html">スタッフ紹介</a></li>
          <li><a href="../../clinic/clinic.html">医院紹介・アクセス</a></li>
          <br class="box_sp">
          <li><a href="../../clinic/flow.html">診療の流れ</a></li>
          <li><a href="../../clinic/sitemap.html">サイトマップ</a></li>
          <li><a href="../../blog/index.php">ブログ</a></li>
        </ul>
      </div>
    </div>
    <address>
    &copy; SAGAMIDAI EKIMAE DENTAL CLINIC, All Rights Reserved.
    </address>
    <p id="toTop"><a href="#wrapper"><img src="../../images/totop.png" width="50" alt="トップへ戻る" /></a></p>
  </div>
  <div id="box_contact" class="box_pc">
    <p class="logo_contact"><img src="../../images/logo_contact.png" alt="CONTACT"/></p>
    <p class="box_contact_add">〒252-0011<br>
      神奈川県座間市相武台1-32-1<br>
      アンプルールベトン相武台1F</p>
    <p class="box_contact_tel">tel.00-00-0000</p>
    <p class="box_contact_time">診療時間<br>
      10:00-13:00 / 15:00-20:00<br>
      （ 土日 18:00まで ）</p>
    <p class="box_contact_bt"><a href="https://www.shika-town.com/" onclick="ga('send', 'event', 'content', 'shikatown');">WEB診療予約</a></p>
  </div>
</div>
<script src="../../js/lightbox-plus-jquery.js"></script>
<script src="../../js/gmaps.js"></script> 
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDcezxGmT3Kw0EjQJGt7MLvWKTQareVCvY&callback=gmaps.renderAll"></script> 
<!-- FS Conversion Analyzer start --> 
<!-- FS Conversion Analyzer end -->
</body>

</html>