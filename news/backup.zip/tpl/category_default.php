<?php

	$setting=unserialize(@file_get_contents(DATA_DIR.'/setting/overnotes.dat'));
	ini_set('mbstring.http_input', 'pass');
	parse_str($_SERVER['QUERY_STRING'],$_GET);
	$keyword=isset($_GET['k'])?trim($_GET['k']):'';
	$category=isset($_GET['c'])?trim($_GET['c']):'';
	$page=isset($_GET['p'])?trim($_GET['p']):'';
	$base_title = !empty($setting['title'])? $setting['title'] : 'OverNotes';

?><!Doctype html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="format-detection" content="telephone=no">
<title><?php echo $current_category_name; ?> | <?php echo $base_title; ?></title>
<meta name="keywords" content="<?php echo $current_category_name; ?> | <?php echo $base_title; ?>" />
<meta name="description" content="<?php echo $current_category_name; ?> | <?php echo $base_title; ?>" />
<meta http-equiv="Content-Style-Type" content="text/css" />
<meta http-equiv="Content-Script-Type" content="text/javascript" />
<link  href="../../css/styles.css" rel="stylesheet" type="text/css" />
<link  href="../../css/style_sp.css" rel="stylesheet" type="text/css" />
<link  href="../../css/responsive.css" rel="stylesheet" type="text/css" />
<link  href="../../css/under.css" rel="stylesheet" type="text/css" />
<link  href="../../css/under_responsive.css" rel="stylesheet" type="text/css" />
<script src="../../js/jquery.js" type="text/javascript"></script>
<script src="../../js/jquery.scroll.js" type="text/javascript"></script>
<script src="../../js/rollover.min.js" type="text/javascript"></script>
<script src="../../js/common.js" type="text/javascript"></script>
<!-- Begin Google Analytics -->
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-90531692-36', 'auto');
  ga('send', 'pageview');

</script>
<!-- End Google Analytics -->
</head>

<body id="case_cate" class="under">
<div id="wrapper">
  <div id="header" class="clearfix">
    <div class="inner">
      <h1 id="top"><?php echo $current_category_name; ?> | <?php echo $base_title; ?></h1>
      <div id="header_top">
        <p id="logo"><a href="http://www.sobudai-d.com"><img src="../../images/logo.png" alt="相武台駅前歯科クリニック"/></a></p>
        <p id="nav-icon4" class="box_sp"><span></span> <span></span> <span></span></p>
        <!--gnavi pc-->
        <ul id="gnavi">
          <li><a href="../../clinic/index.html">コンセプト</a></li>
          <li><a href="../../clinic/staff.html">スタッフ紹介</a></li>
          <li><a href="../../clinic/clinic.html">医院紹介・アクセス</a></li>
          <li><a href="../../clinic/flow.html">診療の流れ</a></li>
        </ul>
        <!--gnavi pc end--> 
        <!--gnavi sp-->
        <div id="gnavi_sp" class="clearfix">
          <ul>
            <li><a href="http://www.sobudai-d.com">トップページ</a></li>
            <li><a href="../../clinic/index.html">コンセプト</a></li>
            <li><a href="../../clinic/staff.html">スタッフ紹介</a></li>
            <li><a href="../../clinic/clinic.html">医院紹介・アクセス</a></li>
            <li><a href="../../clinic/flow.html">診療の流れ</a></li>
            <li><a href="../../clinic/sitemap.html">サイトマップ</a></li>
            <li><a href="../../blog/index.php">ブログ</a></li>
            <li><a href="../../treatment/cost.html">自費と保険の違い</a></li>
            <li><a href="../../clinic/kids.html">お母さんとお子さんが通いやすい歯科医院です</a></li>
            <li class="sub"><a href="#">治療メニュー</a>
              <ul class="sub_menu">
                <li><a href="../../treatment/index.html">虫歯治療</a></li>
                <li><a href="../../treatment/perio.html">歯周病治療</a></li>
                <li><a href="../../treatment/child.html">小児歯科</a></li>
                <li><a href="../../treatment/faq.html">小児歯科のQ&amp;A</a></li>
                <li><a href="../../treatment/prevent.html">予防歯科</a></li>
                <li><a href="../../treatment/implant.html">インプラント治療</a></li>
                <li><a href="../../treatment/denture.html">入れ歯治療</a></li>
                <li><a href="../../treatment/esthe.html">審美歯科･ホワイトニング</a></li>
                <li><a href="../../treatment/ortho.html">矯正歯科</a></li>
                <li><a href="../../treatment/surgery.html">口腔外科</a></li>
              </ul>
            </li>
          </ul>
        </div>
        <!--end gnavi sp--> 
      </div>
    </div>
  </div>
  
  
  <!-- top_info end --> 
  <!-- main start -->
  <div id="main" class="clearfix">
    <div id="top_info" class="clearfix">
      <div class="inner clearfix">
        <h2><?php echo $current_category_name; ?><br>
        	<span>Blog</span>
        </h2>
      </div>
    </div>
    <div id="topic_path" class="clearfix">
      <div class="inner clearfix">
        <ul>
          <li><a href="http://www.sobudai-d.com">ホーム</a>&nbsp;&gt;&nbsp;</li>
          <li><a href="../"><?php echo $base_title; ?></a>&nbsp;&gt;&nbsp;</li>
          <li><?php echo $current_category_name; ?></li>
        </ul>
      </div>
    </div>
    <!-- content start -->
    <div id="content"> 
      <!-- box_h3 start -->
      <div class="under_inner01 clearfix">
        <div class="inner clearfix">
          <h3><?php echo $current_category_name; ?></h3>
          <div class="section clearfix"> 
            <!-- *********   Load category   ********* -->
            <ul class="btn01">
              <?php
	$category_index=get_category_index();
	foreach($category_index as $rowid=>$id){
		$category_data=unserialize(@file_get_contents(DATA_DIR.'/category/'.$id.'.dat'));
		$category_url=$category_data['id'];
		$category_name=$category_data['name'];
		$category_text=@$category_data['text'];
		$category_id=$id;
		${'category'.$id.'_url'}=$category_data['id'];
		${'category'.$id.'_name'}=$category_data['name'];
		${'category'.$id.'_text'}=@$category_data['text'];
		$selected=(@$_GET['c']==$id?' selected="selected"':'');

?>
                <li><a href="../<?php echo $category_url; ?>/"><?php echo $category_name; ?></a></li>
              <?php
	}
?>
            </ul>
            <!-- *********    / Load category ********* --> 
          </div>
        </div>
        </div>
        <div class="under_inner02 clearfix">
        <!-- box_h3 end -->
        <div class="inner clearfix"> 
          <!-- *********   POSTS   ********* -->
          <div class="section clearfix">
            <ul class="tb_cate">
              <?php $limitNum = 6 ?>
              <?php
	$contribute_index=contribute_search(
		@$current_category_id
		,''
		,''
		,''
		,''
		,''
	);
	$max_record_count=count($contribute_index);

	$current_page=(@$_GET['p'])?(@$_GET['p']):1;
	$contribute_index=array_slice($contribute_index,($current_page-1)*$limitNum,$limitNum);
	$record_count=count($contribute_index)

?>
                <?php
	$local_index=0;
	foreach($contribute_index as $rowid=>$index){
		$contribute=unserialize(@file_get_contents(DATA_DIR.'/contribute/'.$index['id'].'.dat'));
		$title=$contribute['title'];
		$url=$contribute['url'].'/';
		$category_id=$index['category'];
		$category_data=unserialize(@file_get_contents(DATA_DIR.'/category/'.$category_id.'.dat'));
		$category_name=$category_data['name'];
		$category_text=@$category_data['text'];
		$field_id=$index['field'];
		$date=$index['public_begin_datetime'];
		$id=$index['id'];
		$field=get_field($field_id);

		foreach($field as $field_index=>$field_data){
			${$field_data['code'].'_Name'}=$field_data['name'];
			${$field_data['code'].'_Value'}=make_value(
		$field_data['name']
				,@$contribute['data'][$field_id][$field_index]
				,$field_data['type']
				,$id
				,$field_id
				,$field_index
			);
	
			if($field_data['type']=='image'){
				${$field_data['code'].'_Src'}=ROOT_URI.'/_data/contribute/images/'.@$contribute['data'][$field_id][$field_index];
			}
		}
		$local_index++;

?>
                  <li>
                    <p class="col_cate"><span class="cate0<?php echo $category_id; ?>"><?php echo $category_name; ?></span><span class="tb_date"><?php echo $date; ?></span></p>
                    <p class="blog_tt"><a href="../<?php echo $url; ?>"><?php echo mb_strimwidth($title, 0, 60, '…', 'UTF-8'); ?></a></p>
                    <p class="img_blog"><a href="../<?php echo $url; ?>">
                      <?php
	if($img_01_Value){
?> <img src="<?php echo $img_01_Src; ?>" alt="<?php echo $title; ?>" />
                        <?php
	}else{
?>
                        <img src="../../images/under_img_02.jpg" alt="<?php echo $title; ?>" /> <?php
	}
?>
                      </a> </p>
                  </li>
                <?php
		foreach($field as $field_index=>$field_data){
			unset(${$field_data['code'].'_Name'});
			unset(${$field_data['code'].'_Value'});
			unset(${$field_data['code'].'_Src'});
		}
	}
?>
              
            </ul>
          </div>
          <!-- *********    /POSTS ********* --> 
          
          <!-- *********   PAGINATION   ********* -->
          <?php
	$page_count=(int)ceil($max_record_count/(float)$limitNum);
?>
            <?php
	if($max_record_count > $limitNum){
?>
              <div class="section clearfix">
                <ul class="pagination">
                  <?php
	if($current_page <= 1){
?>
                    <li class="disabled"><a href="#">&lt;&lt;</a></li>
                    <?php
	}else{
?>
                    <li><a href="./?p=<?php echo $current_page-1; ?>">&lt;&lt;</a></li>
                  <?php
	}
?>
                  <?php
	$page_old=@$page;
	for($page=1;$page<=$page_count;$page++){
?>
                    <?php
	if($current_page == $page){
?>
                      <li class="active"><a href="#"><?php echo $page; ?></a></li>
                      <?php
	}else{
?>
                      <li><a href="./?p=<?php echo $page; ?>"><?php echo $page; ?></a></li>
                    <?php
	}
?>
                  <?php
	}
$page=$page_old;
?>
                  <?php
	if($current_page*$limitNum < $max_record_count){
?>
                    <li><a href="./?p=<?php echo $current_page+1; ?>">&gt;&gt;</a></li>
                    <?php
	}else{
?>
                    <li class="disabled"><a href="#">&gt;&gt;</a></li>
                  <?php
	}
?>
                </ul>
              </div>
            <?php
	}
?>
          
        </div>
        <!-- *********    /PAGINATION ********* --> 
        </div>
      
    </div>
    <!-- content end --> 
  </div>
  <!-- main end -->
  
  <div id="footer">
    <div id="footer_top">
      <div class="inner">
        <p id="footer_logo"><a href="http://www.sobudai-d.com"><img src="../../images/logo_ft.png" alt="相武台駅前歯科クリニック"/></a></p>
        <p class="footer_address">〒252-0011<br class="box_sp">
          神奈川県座間市相武台1-32-1<br class="box_sp">
          アンプルールベトン相武台1F</p>
        <ul>
          <li>駅徒歩1分</li>
          <li>駐車場有</li>
          <li>土日診療</li>
          <li>年中無休</li>
          <li>キッズスペース有</li>
        </ul>
        <p class="footer_tel">tel.00-00-0000</p>
        <p class="footer_time">診療時間<br class="box_sp">
          10:00～13:00　/　15:00～20:00<br class="box_sp">
          （ 土日 18:00まで ）</p>
      </div>
    </div>
    <div class="footer_map">
      <div class="gMap gMapZoom15 gMapDisableScrollwheel gMapNavigationSmall gMapMinifyInfoWindow" style="width:100%; height:450px;">
        <div class="gMapCenter">
          <p class="gMapLatLng">35.4997902,139.40836250000007</p>
        </div>
        <div class="gMapMarker">
          <div class="gMapInfoWindow"><span style="font-weight: bold">相武台駅前歯科クリニック</span><br>
          	〒252-0011 神奈川県座間市相武台1-32-1　アンプルールベトン相武台1F
          </div>
          <p class="gMapLatLng">35.4997902,139.40836250000007</p>
        </div>
      </div>
    </div>
    <div class="inner">
      <p class="link_sika"><a href="https://www.shika-town.com/" onclick="ga('send', 'event', 'content', 'shikatown');"><img src="../../images/sikatown.png" alt="歯科タウン"/></a></p>
    </div>
    <div id="footer_bt">
      <div class="inner">
        <ul>
          <li><a href="../../treatment/index.html">虫歯治療</a></li>
          <li><a href="../../treatment/child.html">小児歯科</a></li>
          <li><a href="../../treatment/perio.html">歯周病治療</a></li>
          <br class="box_sp">
          <li><a href="../../treatment/prevent.html">予防歯科</a></li>
          <li><a href="../../treatment/implant.html">インプラント治療</a></li>
          <br class="box_pc">
          <li><a href="../../treatment/denture.html">入れ歯治療</a></li>
          <br class="box_sp">
          <li><a href="../../treatment/esthe.html">審美歯科・ホワイトニング</a></li>
          <li><a href="../../treatment/ortho.html">矯正歯科</a></li>
          <br class="box_sp">
          <li><a href="../../treatment/surgery.html">口腔外科</a></li>
          <li><a href="../../treatment/cost.html">自費と保険の違い</a></li>
          <br>
          <li><a href="../../clinic/kids.html">お母さんとお子さんが通いやすい歯科医院です</a></li>
          <br class="box_sp">
          <li><a href="../../treatment/faq.html">小児歯科のQ&amp;A</a></li>
          <br class="box_pc">
          <li><a href="http://www.sobudai-d.com">トップページ</a></li>
          <li><a href="../../clinic/index.html">コンセプト</a></li>
          <br class="box_sp">
          <li><a href="../../clinic/staff.html">スタッフ紹介</a></li>
          <li><a href="../../clinic/clinic.html">医院紹介・アクセス</a></li>
          <br class="box_sp">
          <li><a href="../../clinic/flow.html">診療の流れ</a></li>
          <li><a href="../../clinic/sitemap.html">サイトマップ</a></li>
          <li><a href="../../blog/index.php">ブログ</a></li>
        </ul>
      </div>
    </div>
    <address>
    &copy; SAGAMIDAI EKIMAE DENTAL CLINIC, All Rights Reserved.
    </address>
    <p id="toTop"><a href="#wrapper"><img src="../../images/totop.png" width="50" alt="トップへ戻る" /></a></p>
  </div>
  <div id="box_contact" class="box_pc">
    <p class="logo_contact"><img src="../../images/logo_contact.png" alt="CONTACT"/></p>
    <p class="box_contact_add">〒252-0011<br>
      神奈川県座間市相武台1-32-1<br>
      アンプルールベトン相武台1F</p>
    <p class="box_contact_tel">tel.00-00-0000</p>
    <p class="box_contact_time">診療時間<br>
      10:00-13:00 / 15:00-20:00<br>
      （ 土日 18:00まで ）</p>
    <p class="box_contact_bt"><a href="https://www.shika-town.com/" onclick="ga('send', 'event', 'content', 'shikatown');">WEB診療予約</a></p>
  </div>
</div>
<!-- FS Conversion Analyzer start --> 
<!-- FS Conversion Analyzer end --> 
<script type="text/javascript" src="../../js/gmaps.js"></script> 
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBmXeKZTU725aYtku_h_KjcsKUzeUr216E&callback=gmaps.renderAll"></script>
</body>
</html>