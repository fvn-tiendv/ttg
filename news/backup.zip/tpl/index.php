<?php

	$setting=unserialize(@file_get_contents(DATA_DIR.'/setting/overnotes.dat'));
	ini_set('mbstring.http_input', 'pass');
	parse_str($_SERVER['QUERY_STRING'],$_GET);
	$keyword=isset($_GET['k'])?trim($_GET['k']):'';
	$category=isset($_GET['c'])?trim($_GET['c']):'';
	$page=isset($_GET['p'])?trim($_GET['p']):'';
	$base_title = !empty($setting['title'])? $setting['title'] : 'OverNotes';

?><!Doctype html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="format-detection" content="telephone=no">
<title><?php echo $base_title; ?></title>
<meta name="keywords" content="<?php echo $base_title; ?>" />
<meta name="description" content="<?php echo $base_title; ?>" />
<meta http-equiv="Content-Style-Type" content="text/css" />
<meta http-equiv="Content-Script-Type" content="text/javascript" />
<link  href="../css/styles.css" rel="stylesheet" type="text/css" />
<link  href="../css/style_sp.css" rel="stylesheet" type="text/css" />
<link  href="../css/responsive.css" rel="stylesheet" type="text/css" />
<link  href="../css/under.css" rel="stylesheet" type="text/css" />
<link  href="../css/under_responsive.css" rel="stylesheet" type="text/css" />
<script src="../js/jquery.js" type="text/javascript"></script>
<script src="../js/jquery.scroll.js" type="text/javascript"></script>
<script src="../js/rollover.min.js" type="text/javascript"></script>
<script src="../js/common.js" type="text/javascript"></script>
<script src="../js/sweetlink.js" type="text/javascript"></script>
<!-- Google Analytics start -->
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-29058012-1', 'auto');
  ga('send', 'pageview');

</script>
<!-- Google Analytics end -->
</head>

<body id="case" class="under">
<div id="wrapper">

  
  
  <div id="header" class="clearfix">
    <h1 id="top"><?php echo $base_title; ?></h1>
  </div>
  <!-- top_info end --> 
  <!-- main start -->
  <div id="main" class="clearfix"> 
  <div id="top_info" class="clearfix">
      <div class="inner clearfix">
        <h2><?php echo $base_title; ?></h2>
        <p id="info_en">Blog</p>
      </div>
  </div>
  <div id="topic_path" class="clearfix">
        <div class="inner clearfix">
          <ul>
            <li><a href="http://www.sobudai-d.com">ホーム</a>&nbsp;&gt;&nbsp;</li>
            <li><?php echo $base_title; ?></li>
          </ul>
        </div>
      </div>
    <!-- content start -->
    <div id="content"> 
    <div class="under_inner01 clearfix">
        <div class="inner clearfix">
          <h3><?php echo $base_title; ?></h3>
          
		  
		<!-- *********   Load category   ********* -->
            <ul class="btn01">
              <?php
	$category_index=get_category_index();
	foreach($category_index as $rowid=>$id){
		$category_data=unserialize(@file_get_contents(DATA_DIR.'/category/'.$id.'.dat'));
		$category_url=$category_data['id'];
		$category_name=$category_data['name'];
		$category_text=@$category_data['text'];
		$category_id=$id;
		${'category'.$id.'_url'}=$category_data['id'];
		${'category'.$id.'_name'}=$category_data['name'];
		${'category'.$id.'_text'}=@$category_data['text'];
		$selected=(@$_GET['c']==$id?' selected="selected"':'');

?>
                <li> <a href="<?php echo $category_url; ?>/"><?php echo $category_name; ?></a> </li>
              <?php
	}
?>
            </ul>
            
            <!-- *********    / Load category ********* --> 
        </div>
        </div>
        <div class="under_inner02 clearfix">
        <div class="inner clearfix">
        <!-- *********   POSTS   ********* -->
        <div class="section clearfix">
          <ul class="tb_cate">
            <?php $limitNum = 6 ?>
            <?php
	$contribute_index=contribute_search(
		@$current_category_id
		,''
		,''
		,''
		,''
		,''
	);
	$max_record_count=count($contribute_index);

	$current_page=(@$_GET['p'])?(@$_GET['p']):1;
	$contribute_index=array_slice($contribute_index,($current_page-1)*$limitNum,$limitNum);
	$record_count=count($contribute_index)

?>
              <?php
	$local_index=0;
	foreach($contribute_index as $rowid=>$index){
		$contribute=unserialize(@file_get_contents(DATA_DIR.'/contribute/'.$index['id'].'.dat'));
		$title=$contribute['title'];
		$url=$contribute['url'].'/';
		$category_id=$index['category'];
		$category_data=unserialize(@file_get_contents(DATA_DIR.'/category/'.$category_id.'.dat'));
		$category_name=$category_data['name'];
		$category_text=@$category_data['text'];
		$field_id=$index['field'];
		$date=$index['public_begin_datetime'];
		$id=$index['id'];
		$field=get_field($field_id);

		foreach($field as $field_index=>$field_data){
			${$field_data['code'].'_Name'}=$field_data['name'];
			${$field_data['code'].'_Value'}=make_value(
		$field_data['name']
				,@$contribute['data'][$field_id][$field_index]
				,$field_data['type']
				,$id
				,$field_id
				,$field_index
			);
	
			if($field_data['type']=='image'){
				${$field_data['code'].'_Src'}=ROOT_URI.'/_data/contribute/images/'.@$contribute['data'][$field_id][$field_index];
			}
		}
		$local_index++;

?>
                <li>
                  <p class="col_cate"><span class="cate0<?php echo $category_id; ?>"><?php echo $category_name; ?></span><span class="tb_date"><?php echo $date; ?></span></p>
                  <p class="blog_tt"><a href="<?php echo $url; ?>"><?php echo mb_strimwidth($title, 0, 60, '…', 'UTF-8'); ?></a></p>
                  <p class="img_blog"><a href="<?php echo $url; ?>">
                    <?php
	if($img_01_Value){
?> <img src="<?php echo $img_01_Src; ?>" alt="<?php echo $title; ?>" />
                      <?php
	}else{
?>
                      <img src="../images/under_img_02.jpg" alt="<?php echo $title; ?>" /> <?php
	}
?>
                    </a> </p>
                </li>
              <?php
		foreach($field as $field_index=>$field_data){
			unset(${$field_data['code'].'_Name'});
			unset(${$field_data['code'].'_Value'});
			unset(${$field_data['code'].'_Src'});
		}
	}
?>
            
          </ul>
        </div>
        
        <!-- *********    /POSTS ********* --> 
        
        <!-- *********   PAGINATION   ********* -->
        
        <?php
	$page_count=(int)ceil($max_record_count/(float)$limitNum);
?>
          <?php
	if($max_record_count > $limitNum){
?>
            <div class="section clearfix">
              <ul class="pagination">
                <?php
	if($current_page <= 1){
?>
                  <li class="disabled"><a href="#">&lt;&lt;</a></li>
                  <?php
	}else{
?>
                  <li><a href="./?p=<?php echo $current_page-1; ?>">&lt;&lt;</a></li>
                <?php
	}
?>
                <?php
	$page_old=@$page;
	for($page=1;$page<=$page_count;$page++){
?>
                  <?php
	if($current_page == $page){
?>
                    <li class="active"><a href="#"><?php echo $page; ?></a></li>
                    <?php
	}else{
?>
                    <li><a href="./?p=<?php echo $page; ?>"><?php echo $page; ?></a></li>
                  <?php
	}
?>
                <?php
	}
$page=$page_old;
?>
                <?php
	if($current_page*$limitNum < $max_record_count){
?>
                  <li><a href="./?p=<?php echo $current_page+1; ?>">&gt;&gt;</a></li>
                  <?php
	}else{
?>
                  <li class="disabled"><a href="#">&gt;&gt;</a></li>
                <?php
	}
?>
              </ul>
            </div>
          <?php
	}
?>
        
        </div>
        <!-- *********    /PAGINATION ********* --> 
         </div>
      
    </div>
  </div>
  <!-- content end --> 
  
  <!-- main end -->
  
  <div id="footer">
    <address>
    Copyright &copy; All Rights Reserved.
    </address>
  </div>
</div>
<!-- FS Conversion Analyzer start --> 
<!-- FS Conversion Analyzer end --> 
<script type="text/javascript" src="../js/gmaps.js"></script> 
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBmXeKZTU725aYtku_h_KjcsKUzeUr216E&callback=gmaps.renderAll"></script>
</body>
</html>